/*
Enhanced server with SQLite, Passport Google OAuth (placeholders), referrals and payout ledger.
Fill GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET as env vars before using OAuth.
*/
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const qrcode = require('qrcode');
const sqlite3 = require('sqlite3').verbose();
const { v4: uuidv4 } = require('uuid');
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const session = require('express-session');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use('/public', express.static(path.join(__dirname, 'public')));

app.use(session({ secret: process.env.SESSION_SECRET || 'change_this', resave: false, saveUninitialized: true }));
app.use(passport.initialize());
app.use(passport.session());

const db = new sqlite3.Database('data.db');

passport.serializeUser((user, done) => done(null, user.id));
passport.deserializeUser((id, done) => {
  db.get('SELECT * FROM users WHERE id = ?', [id], (err, row) => {
    if(err) return done(err);
    done(null, row);
  });
});

const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID || 'FILL_ME';
const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET || 'FILL_ME';

passport.use(new GoogleStrategy({
  clientID: GOOGLE_CLIENT_ID,
  clientSecret: GOOGLE_CLIENT_SECRET,
  callbackURL: '/auth/google/callback'
}, (accessToken, refreshToken, profile, done) => {
  // find or create user in DB
  const googleId = profile.id;
  const email = (profile.emails && profile.emails[0] && profile.emails[0].value) || null;
  db.get('SELECT * FROM users WHERE google_id = ?', [googleId], (err,row) => {
    if(err) return done(err);
    if(row){
      return done(null, row);
    } else {
      const id = uuidv4();
      const created = Date.now();
      // check for ref in session (simple)
      const referrer = (profile._json && profile._json.referrer) || null;
      db.run('INSERT INTO users(id,google_id,email,created_at,referrer_id) VALUES(?,?,?,?,?)', [id, googleId, email, created, referrer], function(err){
        if(err) return done(err);
        const user = { id, google_id: googleId, email, created_at: created, referrer_id: referrer };
        done(null, user);
      });
    }
  });
}));

app.get('/', (req,res) => res.sendFile(path.join(__dirname, 'index.html')));
app.get('/admin', (req,res) => res.sendFile(path.join(__dirname, 'admin.html')));

// Auth routes
app.get('/auth/google', (req,res,next) => {
  // Save ref param if present
  if(req.query.ref) req.session.ref = req.query.ref;
  passport.authenticate('google', { scope: ['profile','email'] })(req,res,next);
});
app.get('/auth/google/callback', passport.authenticate('google', { failureRedirect: '/' }), (req,res) => {
  // on success, attach referrer if present
  const userId = req.user.id;
  if(req.session && req.session.ref){
    const ref = req.session.ref;
    db.run('UPDATE users SET referrer_id = ? WHERE id = ?', [ref, userId]);
    db.run('INSERT INTO referrals(referrer_id, referred_id, created_at) VALUES(?,?,?)', [ref, userId, Date.now()]);
  }
  res.redirect('/');
});

// API: request jackpot / payout
app.post('/api/request-jackpot', (req,res) => {
  const userId = req.body.userId || 'anon-' + uuidv4();
  const amount = Number(req.body.amount) || 0;
  db.run('INSERT INTO payouts(user_id,amount,status,created_at) VALUES(?,?,?,?)', [userId, amount, 'requested', Date.now()], function(err){
    if(err) return res.status(500).json({ok:false, error:err.message});
    res.json({ok:true, id: this.lastID});
  });
});

// Admin settings
app.post('/api/admin/settings', (req,res) => {
  const adminPct = String(req.body.adminPct || '10');
  const refPct = String(req.body.refPct || '5');
  db.run('INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)', ['adminPct', adminPct]);
  db.run('INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)', ['refPct', refPct]);
  res.send('ok');
});

app.get('/api/admin/ledger', (req,res) => {
  db.all('SELECT * FROM payouts ORDER BY created_at DESC LIMIT 200', [], (err, rows) => {
    if(err) return res.status(500).json({error:err.message});
    res.json(rows);
  });
});

app.post('/api/admin/process-payouts', (req,res) => {
  // mock processing: mark requested payouts as processed and store processed_at
  db.run("UPDATE payouts SET status='processed', processed_at=? WHERE status='requested'", [Date.now()], function(err){
    if(err) return res.status(500).json({ok:false, error:err.message});
    res.json({ok:true, processed:this.changes});
  });
});

// QR generator
app.get('/api/qr', async (req,res) => {
  const url = req.query.u || 'https://example.com';
  try {
    const data = await qrcode.toDataURL(url);
    const img = Buffer.from(data.split(',')[1], 'base64');
    res.type('png').send(img);
  } catch(e){ res.status(500).send('qr error'); }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log('Server running on', PORT));


// --- Referral system for TRON wallets ---
// Stores incoming ?ref=WALLET in a cookie for later registration linking.
const cookieParser = require('cookie-parser');
app.use(cookieParser());

app.use((req, res, next) => {
  try {
    const ref = req.query.ref;
    if (ref) {
      // set cookie for 30 days
      res.cookie('referrer_wallet', ref, { maxAge: 30*24*60*60*1000, httpOnly: false });
      console.log('Stored referrer_wallet cookie:', ref);
    }
  } catch (e) { console.error(e); }
  next();
});

// When user registers, client should send { wallet: 'TRX...', ref: '...' }.
// Example handler below tries to link by wallet/ref and increment referrals count.
app.post('/api/register', async (req, res) => {
  try {
    const wallet = req.body.wallet;
    // prefer ref provided in body, otherwise from cookie
    const ref = req.body.ref || req.cookies && req.cookies.referrer_wallet;
    if (!wallet) return res.status(400).json({ error: 'wallet required' });

    // create user (pseudo - adapt to your DB)
    const user = { wallet: wallet, createdAt: new Date(), referrals: 0 };
    // If you have a db.users.insertOne, use it. Here we try to be generic.
    if (db && db.users && typeof db.users.insertOne === 'function') {
      await db.users.insertOne(user);
    } else if (typeof saveUser === 'function') {
      await saveUser(user);
    } else {
      // fallback: log
      console.log('Register user:', user);
    }

    // link referrer: increment their referrals counter
    if (ref) {
      try {
        if (db && db.users && typeof db.users.updateOne === 'function') {
          await db.users.updateOne({ wallet: ref }, { $inc: { referrals: 1 } });
        } else {
          console.log('Would increment referrals for', ref);
        }
      } catch (e) { console.error('Referrer update failed', e); }
    }

    return res.json({ ok: true, wallet, ref: ref || null });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'server error' });
  }
});


// Simple QR endpoint (returns SVG) - uses Google Chart API as lightweight fallback.
// Example: /referral/qr?text=https://... -> returns an <img> friendly SVG/png proxy.
const fetch = require('node-fetch');

app.get('/referral/qr', async (req, res) => {
  const text = req.query.text || '';
  if (!text) return res.status(400).send('text required');
  try {
    const url = 'https://chart.googleapis.com/chart?cht=qr&chs=200x200&chl=' + encodeURIComponent(text);
    const r = await fetch(url);
    const buffer = await r.buffer();
    res.set('Content-Type', 'image/png');
    return res.send(buffer);
  } catch (e) {
    console.error('QR proxy failed', e);
    return res.status(500).send('qr error');
  }
});


// ---- Admin wallet JSON storage ----
const fs = require('fs');

// Load admin wallet
app.get('/admin/getWallet', (req, res) => {
    try {
        const data = JSON.parse(fs.readFileSync('./db/admin.json','utf8'));
        res.json({ wallet: data.admin_wallet || "" });
    } catch(e){
        res.json({ wallet: "" });
    }
});

// Save admin wallet
app.post('/admin/setWallet', (req, res) => {
    try {
        const wallet = req.body.wallet;
        if (!/^T[a-zA-Z0-9]{33}$/.test(wallet)) {
            return res.status(400).json({ error: "Invalid TRON wallet" });
        }
        const data = { admin_wallet: wallet };
        fs.writeFileSync('./db/admin.json', JSON.stringify(data, null, 2));
        res.json({ ok: true, wallet });
    } catch(e){
        res.status(500).json({ error: "write error" });
    }
});
